import React, { Component } from 'react';
import style from './Main.module.css';

class Main extends Component {
    render(){
        return(
            <div className={ style.mainbox }>
                {this.props.children}
            </div>
        )
    }

}


export default Main