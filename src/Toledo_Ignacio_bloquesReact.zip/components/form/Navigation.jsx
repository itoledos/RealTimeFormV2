import React, { Component } from 'react';
import style from './Navigation.module.css';

class Navigation extends Component {
    render() {
        return(
            <div className={ style.navbar }>
                .
            </div>
        )
    }
}

export default Navigation