import React, { Component } from 'react';
import style from './Advertisement.module.css';

class Advertisement extends Component {
    render(){
        return(
            <div className={ style.advert }>

            </div>
        )
    }
}


export default Advertisement