import React, { Component } from 'react';
import style from './SubContent.module.css';

class SubContent extends Component {
    render() {
        return(
            <div className={ style.subcont }>
                .
            </div>
        )
    }
}

export default SubContent